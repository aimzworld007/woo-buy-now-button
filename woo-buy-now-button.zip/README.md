# WooCommerce Buy Now Button
Adds Buy Now button for WooCommerce with customizable labels, colors, and position.
