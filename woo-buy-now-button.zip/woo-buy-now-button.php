<?php
/*
Plugin Name: WooCommerce Buy Now Button (Blocks + Single Product)
Description: Adds Buy Now button in WooCommerce grids and single product pages. Admin can edit labels, colors, position.
Version: 1.6
Author: Ainul islam
License: GPL2
*/
